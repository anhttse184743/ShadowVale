using ShadowVale.Gameplay.Player;
using UnityEngine;
using UnityEngine.InputSystem;

namespace ShadowVale.Gameplay.Combat
{
    /// <summary>
    /// Greybox combat for the test map: carries every weapon at once and swaps which one is
    /// visible, fires on left mouse, aims down sights on right mouse (guns only).
    /// Guns trace from the camera centre so the shot lands where the crosshair is; melee sweeps
    /// a sphere forward from the character.
    /// </summary>
    [RequireComponent(typeof(PlayerController))]
    public sealed class PlayerCombat : MonoBehaviour
    {
        /// <summary>
        /// Every animator parameter the player rig uses — locomotion and combat both.
        /// Single source of truth, mirrored by PlayerAnimatorBuilder.
        /// </summary>
        public static class AnimatorParams
        {
            public const string Speed = "Speed";
            public const string Grounded = "Grounded";
            public const string Jump = "Jump";
            public const string Sneaking = "Sneaking";
            public const string Weapon = "Weapon";
            public const string Attack = "Attack";
            public const string Aiming = "Aiming";
            public const string Die = "Die";
            public const string SneakCycle = "SneakCycle";
        }

        /// <summary>Animator layer holding the weapon stance. Muted when empty-handed.</summary>
        public const string UpperBodyLayer = "UpperBody";

        /// <summary>
        /// Base-layer state the character stands in while alive. Reviving jumps straight back to
        /// it, and the animator builder creates it under this name — one constant, so renaming the
        /// state cannot silently break coming back from the dead.
        /// </summary>
        public const string LocomotionState = "Locomotion";

        /// <summary>
        /// Default hotbar order, left to right: 1 rifle, 2 knife. There is no bare-hands slot any
        /// more: something is always in hand. The HUD reads this, so the slots on screen and the
        /// number keys can never drift apart. A scene with its own loadout takes the keys over
        /// through <see cref="SlotPressed"/> (Map 1: 1 long gun, 2 pistol, 3 knife, 4 throwable).
        /// </summary>
        public static readonly WeaponKind[] SlotOrder =
        {
            WeaponKind.Rifle,
            WeaponKind.Knife,
        };

        private static readonly Key[] SlotKeys = { Key.Digit1, Key.Digit2, Key.Digit3, Key.Digit4 };
        public System.Func<bool> InputAllowed { get; set; }

        /// <summary>
        /// A number key (0 for "1") goes to the scene first; returning true means the scene handled
        /// it and the default <see cref="SlotOrder"/> is not consulted.
        /// </summary>
        public System.Func<int, bool> SlotPressed { get; set; }

        /// <summary>
        /// Legacy per-shot ammo gate, kept for scenes that never configured a magazine. Once a
        /// magazine exists it owns the round count and this is not consulted: the reserve is
        /// drawn on reload through <see cref="DrawRounds"/> instead, so a shot costs one round
        /// from the weapon rather than one from the pack.
        /// </summary>
        public System.Func<bool> TryConsumeRound { get; set; }

        /// <summary>
        /// Asked before a gun fires: false when the gun in hand cannot (worn to nothing). Settled before the
        /// magazine, so a broken gun keeps its rounds and mimes no shot. Left unset, every gun fires.
        /// </summary>
        public System.Func<bool> GunUsable { get; set; }
        public System.Func<WeaponKind,bool> EquipAllowed { get; set; }

        /// <summary>
        /// Asked for rounds when the magazine reloads; returns how many the reserve could give.
        /// Left unset, reloads draw on an unlimited supply, which is what a greybox scene wants.
        /// </summary>
        public System.Func<int, int> DrawRounds { get; set; }

        /// <summary>Rounds left in the reserve, for the HUD and for refusing a pointless reload.</summary>
        public System.Func<int> ReserveRounds { get; set; }
        /// <summary>The scene draws the weapon slots in its own HUD, so the stock hotbar row
        /// (<c>WeaponHotbar</c>) stays hidden. The number keys are 1/2/3 either way.</summary>
        public bool DrawsOwnWeaponHud { get; set; }
        public float AttackCooldownRemaining => Mathf.Max(0, _nextAttackTime - Time.time);

        /// <summary>Half-angle of the cone the next shot can land in, in degrees.</summary>
        public float CurrentSpreadDegrees => _spread.ConeHalfAngle(CurrentStance(), _aiming, _equippedKind, _equipped != null && _equipped.UsesM16Handling);

        /// <summary>0 to 1. How far sustained fire has opened the cone.</summary>
        public float SpreadBloom => _spread.Bloom;

        /// <summary>Shots into the current burst.</summary>
        public int BurstShotIndex => _spread.ShotIndex;

        /// <summary>Rounds in the weapon right now.</summary>
        public int RoundsInMagazine => _magazine?.Rounds ?? 0;

        public int MagazineCapacity => _magazine?.Capacity ?? 0;
        public bool IsReloading => _magazine is { IsReloading: true };
        public float ReloadDurationMultiplier {get;set;}=1f;
        public float BaseReloadSeconds => _activeTuning.OrDefault().reloadSeconds;
        public bool EquippedIsGun => _equipped != null && _equipped.IsGun;
        public float StanceBlendSeconds => Mathf.Max(.01f, stanceBlendTime);
        public int ReloadPlannedRounds => _magazine?.ReloadPlannedRounds??0;
        public float FullReloadProgress => _magazine?.FullReloadProgress??0;

        public Weapon WeaponFor(WeaponKind kind) => _weapons.TryGetValue(kind, out var value) ? value : null;
        public int MagazineRounds(WeaponKind kind) => _magazines.TryGetValue(kind, out var value) ? value.Rounds : 0;
        public void RestoreMagazine(WeaponKind kind, int rounds)
        {
            if (_magazines.TryGetValue(kind, out var value)) value.Refill(rounds);
        }

        /// <summary>Register an extra gun without regenerating the existing player/loadout prefab.</summary>
        public bool RegisterWeapon(Weapon weapon, WeaponTuning handling, int loadedRounds = 0)
        {
            if (weapon == null || !weapon.IsGun || _weapons.ContainsKey(weapon.Kind)) return false;
            handling = handling.OrDefault();
            var magazine = handling.Create(); magazine.Refill(loadedRounds);
            _weapons.Add(weapon.Kind, weapon); _magazines.Add(weapon.Kind, magazine);
            _tunings.Add(weapon.Kind, handling); weapon.gameObject.SetActive(false);
            return true;
        }

        public void CancelReload()
        {
            _magazine?.CancelReload();
            if (animator != null && _hasReloadParams) animator.ResetTrigger("Reload");
        }

        /// <summary>0 to 1 across a reload, for a HUD bar. 0 when not reloading.</summary>
        public float ReloadProgress => _magazine?.ReloadProgress ?? 0f;
        public System.Func<bool> ProneReloadAvailable { get; set; }

        /// <summary>Puts a saved round count back in the weapon and clears any reload.</summary>
        public void RestoreMagazine(int rounds) => _magazine?.Refill(rounds);

        /// <summary>Starts a reload if one is possible. Returns false when it is not.</summary>
        public bool TryReload()
        {
            if (_handsOccupied || _magazine == null || _equipped == null || !_equipped.IsGun) return false;
            bool proneReload = _controller != null && _controller.IsProne && (ProneReloadAvailable?.Invoke() ?? false);
            if (_controller != null && _controller.IsProne && !proneReload && !_controller.TrySetProne(false)) return false;
            bool wasEmpty = _magazine.IsEmpty;
            var skills = GetComponent<ShadowVale.Gameplay.Skills.PlayerSkills>();
            if (!_magazine.BeginReload(ReserveRounds != null ? ReserveRounds() : -1, (skills != null ? skills.ReloadMultiplier : 1f)*Mathf.Max(.1f,ReloadDurationMultiplier))) return false;
            if (!proneReload) AnimateReload(wasEmpty);
            return true;
        }

        /// <summary>
        /// Nam's own reload takes (Blender): swapping a part-used magazine, an empty one, or crouched.
        /// Played at whatever pace makes the take end as the magazine timer does.
        /// </summary>
        private void AnimateReload(bool wasEmpty)
        {
            if (_equippedKind == WeaponKind.Pistol || _equippedKind == WeaponKind.Sniper) return; // Authored pose players follow the real magazine timer.
            if (animator == null || !_hasReloadParams) return;
            bool crouched = _controller != null && _controller.IsSneaking;
            float length = ClipLength(crouched ? "Nam_Crouch_Reload" : wasEmpty ? "Nam_Rifle_Reload" : "Nam_Rifle_ReloadTactical");
            animator.SetBool("ReloadEmpty", wasEmpty);
            animator.SetFloat("ReloadSpeed", length > 0 ? length / Mathf.Max(0.1f, _magazine.ReloadRemaining) : 1f);
            animator.SetTrigger("Reload");
        }

        private float ClipLength(string clipName)
        {
            if (animator.runtimeAnimatorController == null) return 0f;
            foreach (AnimationClip clip in animator.runtimeAnimatorController.animationClips)
                if (clip != null && clip.name == clipName) return clip.length;
            return 0f;
        }
        public void RestoreAttackCooldown(float remaining) => _nextAttackTime = Time.time + Mathf.Max(0, remaining);

        [Header("Loadout")]
        [Tooltip("Weapon prefabs, spawned once and parented to the hand anchor.")]
        [SerializeField] private Weapon[] weaponPrefabs = System.Array.Empty<Weapon>();

        [Tooltip("Usually the right hand bone. Weapons are parented here at their own local zero.")]
        [SerializeField] private Transform handAnchor;

        [SerializeField] private WeaponKind startingWeapon = WeaponKind.Rifle;

        [Tooltip("Hand-tuned grip offsets. Without one, weapons sit at the anchor's origin.")]
        [SerializeField] private WeaponGripConfig gripConfig;

        [Tooltip("Seconds to fade the weapon-stance layer in and out.")]
        [SerializeField] private float stanceBlendTime = 0.15f;

        [Tooltip("Seconds to swing the weapon between its carry pose and its levelled aim pose.")]
        [SerializeField] private float gripBlendTime = 0.12f;

        [Tooltip("Extra seconds the stance layer stays up after an unarmed attack, so the punch " +
                 "animation is not cut off by the layer fading.")]
        [SerializeField] private float attackLayerTail = 0.3f;

        [Tooltip("Extra seconds the body stays turned toward the camera after the last shot, so " +
                 "firing single shots does not leave the character swivelling back and forth.")]
        [SerializeField] private float faceCameraTail = 0.6f;

        /// <summary>Raised on equip so the HUD can follow without polling.</summary>
        public event System.Action<WeaponKind> WeaponChanged;

        /// <summary>
        /// Raised the moment an attack commits — after the round is spent, before the trace.
        /// Carries the weapon used and where the sound comes from, so audio and anything else
        /// that reacts to a shot can hang off one place instead of reaching into the internals.
        /// </summary>
        public event System.Action<WeaponKind, Vector3> Attacked;

        [Header("Magazine")]
        [SerializeField] private WeaponTuning tuning = WeaponTuning.Rifle;

        [Header("Unarmed")]
        [SerializeField] private float punchDamage = 12f;
        [SerializeField] private float punchRange = 1.5f;
        [SerializeField] private float punchCooldown = 0.45f;
        [SerializeField] private float punchSweepRadius = 0.3f;

        [Header("Targeting")]
        [Tooltip("What shots and swings can hit. Exclude the player's own layer.")]
        [SerializeField] private LayerMask hitMask = ~0;

        [Header("Tracers")]
        [Tooltip("Bullet streak spawned per shot. Optional — shooting works without it.")]
        [SerializeField] private ShotTracer tracerPrefab;
        public ShotTracer TracerPrefab => tracerPrefab;

        [Tooltip("How many streaks can overlap. A full pool reuses the oldest.")]
        [SerializeField] private int tracerPoolSize = 12;

        [Header("Wiring")]
        [SerializeField] private Animator animator;
        [SerializeField] private ThirdPersonCamera cameraRig;
        [SerializeField] private Health health;

        private readonly System.Collections.Generic.Dictionary<WeaponKind, Weapon> _weapons = new();
        private PlayerController _controller;
        private CharacterController _characterController;
        private Weapon _equipped;
        private WeaponKind _equippedKind;
        private float _nextAttackTime;
        private Magazine _magazine;
        private readonly System.Collections.Generic.Dictionary<WeaponKind, Magazine> _magazines = new();
        private readonly System.Collections.Generic.Dictionary<WeaponKind, WeaponTuning> _tunings = new();
        private WeaponTuning _activeTuning;
        private readonly WeaponSpreadState _spread = new();
        private bool _aiming;
        private bool _firingHeld;
        private bool _automaticBurst;
        private float _stanceYaw;
        private ShotTracer[] _tracers;
        private Transform _tracerRoot;
        private int _tracerCursor;
        private int _upperBodyLayer = -1;
        private float _aimPoseBlend;
        private float _upperBodyWeight;
        /// <summary>Base-layer state holding Nam's own AK carry, when the controller has one.</summary>
        public const string RifleLocomotionState = "Locomotion_Rifle";
        private bool _rifleBody, _hasReloadParams;
        private static readonly int KnifeLocomotionHash = Animator.StringToHash("Locomotion_Knife");
        private bool HasKnifeCarry => animator!=null&&animator.HasState(0,KnifeLocomotionHash);
        private float _upperBodyHoldUntil;
        private float _faceCameraHoldUntil;
        private float _fireHoldUntil;
        private BarrelAim _barrelAim;

        /// <summary>The rifle in hand, or null with anything else out.</summary>
        internal Weapon Gun => !_handsOccupied && _equipped != null && _equipped.IsGun ? _equipped : null;
        private bool _handsOccupied;
        /// <summary>The hands hold something other than the weapon (a load, a tool); the weapon cannot be used.</summary>
        public bool HandsOccupied => _handsOccupied;

        /// <summary>Free the hands for a held item while preserving the equipped weapon and ammunition.</summary>
        public void SetHandsOccupied(bool occupied)
        {
            if(!occupied && !_handsOccupied)return;
            _handsOccupied=occupied;
            _firingHeld=false;
            _automaticBurst=false;
            SetAiming(false);_upperBodyHoldUntil=_faceCameraHoldUntil=_fireHoldUntil=0;
            _aimPoseBlend=0;_upperBodyWeight=0;_magazine?.CancelReload();_pendingGunfire.Clear();
            _controller?.SetFaceCameraYaw(false);
            if(occupied)cameraRig?.ClearRecoil();
            if(animator==null || animator.runtimeAnimatorController==null)return;
            animator.SetBool(AnimatorParams.Aiming,false);
            animator.SetInteger(AnimatorParams.Weapon,occupied?0:(int)_equippedKind);
            animator.ResetTrigger(AnimatorParams.Attack);
            if(_hasReloadParams)animator.ResetTrigger("Reload");
            if(_upperBodyLayer>0) {
                animator.SetLayerWeight(_upperBodyLayer,0);
                string upper=occupied?"Empty":_equippedKind==WeaponKind.Rifle?"Hold_Rifle":"Hold_Knife";
                if(animator.HasState(_upperBodyLayer,Animator.StringToHash(upper)))animator.Play(upper,_upperBodyLayer,0);
            }
            bool crouched=_controller!=null && _controller.IsSneaking;
            string state=occupied?(crouched?"Sneak":LocomotionState):_equippedKind==WeaponKind.Rifle
                ?(crouched?"Sneak_Rifle":RifleLocomotionState):_equippedKind==WeaponKind.Knife && HasKnifeCarry
                ?(crouched?"Sneak_Knife":"Locomotion_Knife"):(crouched?"Sneak":LocomotionState);
            if(animator.HasState(0,Animator.StringToHash(state)))animator.CrossFadeInFixedTime(state,.1f,0);
        }

        /// <summary>
        /// True while the takes hold the rifle up to shoot — sights raised, or a round just fired from the hip —
        /// which is when <see cref="BarrelAim"/> lays the barrel on the crosshair. A flinch raises the stance
        /// layer too, but leaves the rifle in its carry: that does not count.
        /// </summary>
        public bool GunPresentationReady { get; set; } = true;
        internal bool RifleLevelled => Gun != null && GunPresentationReady && (_aiming || _firingHeld || Time.time < _fireHoldUntil);

        internal bool RecoilPosePlaying => animator != null && _upperBodyLayer > 0
            && (animator.GetCurrentAnimatorStateInfo(_upperBodyLayer).IsName("Attack_Rifle")
                || (animator.IsInTransition(_upperBodyLayer)
                    && animator.GetNextAnimatorStateInfo(_upperBodyLayer).IsName("Attack_Rifle")));

        internal int HitMask => hitMask;

        public WeaponKind EquippedKind => _equippedKind;
        public WeaponKind StartingWeapon => startingWeapon;
        public bool IsAiming => _aiming;
        /// <summary>Optional mission-specific melee interaction, before ordinary damage.</summary>
        public System.Func<bool> TrySpecialMelee { get; set; }

        // Rebind clears Animator parameters even when the cached aiming flag is unchanged.
        // Restore gameplay explicitly rather than waiting for another input edge.
        /// <summary>Seat the equipped prop in its authored carry grip before a locomotion playable takes over.</summary>
        public void PrepareCinematicCarry()
        {
            _aiming=false;_aimPoseBlend=0;_upperBodyHoldUntil=_faceCameraHoldUntil=_fireHoldUntil=0;
            if(animator!=null){animator.SetBool(AnimatorParams.Aiming,false);if(_upperBodyLayer>0)animator.SetLayerWeight(_upperBodyLayer,0);}
            if(_equipped!=null&&gripConfig!=null)gripConfig.Apply(_equipped.transform,_equippedKind,false);
        }

        public void RestoreAfterCinematic()
        {
            if (animator == null || animator.runtimeAnimatorController == null) return;
            animator.Rebind();
            _upperBodyHoldUntil=_faceCameraHoldUntil=_fireHoldUntil=0;
            _nextAttackTime=Time.time;
            _magazine?.CancelReload();_spread.Reset();
            _rifleBody=animator.HasState(0,Animator.StringToHash(RifleLocomotionState));
            _upperBodyLayer = animator.GetLayerIndex(UpperBodyLayer);
            animator.SetInteger(AnimatorParams.Weapon, (int)_equippedKind);
            animator.SetFloat(AnimatorParams.Speed, 0);
            animator.SetBool(AnimatorParams.Grounded, true);
            animator.SetBool(AnimatorParams.Sneaking, _controller != null && _controller.IsSneaking);
            animator.ResetTrigger(AnimatorParams.Attack); animator.ResetTrigger(AnimatorParams.Die);
            // Clear the cinematic pose; gameplay polls the held aim button on its next update.
            _aiming = false;
            animator.SetBool(AnimatorParams.Aiming, _aiming);
            bool rifleCarry=_rifleBody && _equippedKind==WeaponKind.Rifle && !_aiming;
            bool knifeCarry=HasKnifeCarry&&_equippedKind==WeaponKind.Knife;
            _upperBodyWeight = _equippedKind == WeaponKind.Unarmed || rifleCarry || knifeCarry ? 0 : 1;
            if (_upperBodyLayer > 0) {
                animator.SetLayerWeight(_upperBodyLayer, _upperBodyWeight);
                string state = _equippedKind == WeaponKind.Rifle ? "Hold_Rifle" : _equippedKind == WeaponKind.Knife ? "Hold_Knife" : "Empty";
                if (animator.HasState(_upperBodyLayer, Animator.StringToHash(state))) animator.Play(state, _upperBodyLayer, 0);
            }
            string locomotion=knifeCarry?(_controller!=null&&_controller.IsSneaking?"Sneak_Knife":"Locomotion_Knife"):rifleCarry?RifleLocomotionState:LocomotionState;
            if (animator.HasState(0, Animator.StringToHash(locomotion))) animator.Play(locomotion, 0, 0);
            foreach (var pair in _weapons) pair.Value.gameObject.SetActive(pair.Key == _equippedKind);
            // Cinematic NPC grips may have reparented/resized this existing gameplay rifle.
            if(_equipped!=null) {
                _equipped.transform.SetParent(handAnchor!=null?handAnchor:transform,false);
                if(gripConfig!=null)gripConfig.Apply(_equipped.transform,_equippedKind,_aiming);
            }
            _aimPoseBlend = _aiming ? 1 : 0;
            if (cameraRig != null) {cameraRig.ClearRecoil(); cameraRig.SetAiming(_aiming);}
            UpdateGripPose(); UpdateFacing(); animator.Update(0);
            if(_handsOccupied)SetHandsOccupied(true);
        }

        private void Awake()
        {
            if(GetComponent<GunfireFrame>()==null)gameObject.AddComponent<GunfireFrame>();
            _controller = GetComponent<PlayerController>();
            _characterController = GetComponent<CharacterController>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
            if (health == null) health = GetComponent<Health>();
            if (cameraRig == null && Camera.main != null)
            {
                cameraRig = Camera.main.GetComponent<ThirdPersonCamera>();
            }

            if (animator != null)
            {
                _upperBodyLayer = animator.GetLayerIndex(UpperBodyLayer);
                _rifleBody = animator.runtimeAnimatorController != null
                    && animator.HasState(0, Animator.StringToHash(RifleLocomotionState));
                foreach (AnimatorControllerParameter p in animator.parameters)
                {
                    if (p.name == "ReloadSpeed") _hasReloadParams = true;
                }
            }

            // Added here rather than on the prefab: every character that shoots through this needs it.
            if (!TryGetComponent(out _barrelAim)) _barrelAim = gameObject.AddComponent<BarrelAim>();
            _barrelAim.Bind(this, animator);

            tuning = tuning.OrDefault();
            _magazine = tuning.Create();
            _activeTuning = tuning;
            _magazines[WeaponKind.Rifle] = _magazine;
            _tunings[WeaponKind.Rifle] = tuning;

            SpawnWeapons();
            SpawnTracerPool();
            Equip(startingWeapon);

            // Snap the stance layer to where it belongs instead of fading in from zero: the
            // controller starts it at full weight, so a cold start would pop.
            if (animator != null && _upperBodyLayer > 0)
            {
                _upperBodyWeight = _equippedKind != WeaponKind.Unarmed ? 1f : 0f;
                animator.SetLayerWeight(_upperBodyLayer, _upperBodyWeight);
            }
        }

        private void SpawnWeapons()
        {
            Transform parent = handAnchor != null ? handAnchor : transform;

            foreach (Weapon prefab in weaponPrefabs)
            {
                if (prefab == null || _weapons.ContainsKey(prefab.Kind))
                {
                    continue;
                }

                Weapon instance = Instantiate(prefab, parent);
                // The prefab's own transform is meaningless here — the grip config is what says
                // where this weapon sits in the fist.
                if (gripConfig != null)
                {
                    gripConfig.Apply(instance.transform, prefab.Kind);
                }
                else
                {
                    instance.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                    instance.transform.localScale = Vector3.one;
                }
                instance.gameObject.SetActive(false);
                _weapons[prefab.Kind] = instance;
            }
        }

        /// <summary>
        /// Tracers are pre-made and reused: shots come out fast enough that allocating one per
        /// bullet would churn. The root belongs to this actor so it follows scene transfers;
        /// world-space line positions keep already-fired streaks fixed when the actor moves.
        /// </summary>
        private void SpawnTracerPool()
        {
            if (tracerPrefab == null)
            {
                return;
            }

            // Adopt an existing pool after an editor script reload instead of duplicating it.
            if (_tracerRoot == null) _tracerRoot = transform.Find("ShotTracers");
            if (_tracerRoot == null && _tracers != null)
                foreach (var tracer in _tracers)
                    if (tracer != null && tracer.transform.parent != null)
                    {
                        _tracerRoot = tracer.transform.parent;
                        break;
                    }
            if (_tracerRoot == null) _tracerRoot = new GameObject("ShotTracers").transform;
            _tracerRoot.SetParent(transform, false);
            var existing = _tracerRoot.GetComponentsInChildren<ShotTracer>(true);
            _tracers = new ShotTracer[Mathf.Max(1, tracerPoolSize)];
            _tracerCursor = 0;
            for (int i = 0; i < _tracers.Length; i++)
            {
                _tracers[i] = i < existing.Length ? existing[i] : Instantiate(tracerPrefab, _tracerRoot);
            }
            for (int i = _tracers.Length; i < existing.Length; i++) Destroy(existing[i].gameObject);
        }

        private ShotTracer GetUsableTracer(int index)
        {
            var tracer = _tracers[index];
            if (tracer != null && tracer.IsUsable) return tracer;
            // Repair only a lost slot, never allocate a new streak for every shot.
            if (tracer != null) Destroy(tracer.gameObject);
            return _tracers[index] = Instantiate(tracerPrefab, _tracerRoot);
        }

        private void OnDestroy()
        {
            if (_tracerRoot != null) Destroy(_tracerRoot.gameObject);
        }

        private void ShowTracer(Vector3 from, Vector3 to) => PlayTracer(from,to);

        private ShotTracer PlayTracer(Vector3 from, Vector3 to)
        {
            if (tracerPrefab == null) return null;
            if (_tracerRoot == null || _tracers == null || _tracers.Length == 0) SpawnTracerPool();
            if (_tracers == null || _tracers.Length == 0)
            {
                return null;
            }

            // Prefer a free one; if every streak is still flashing, recycle at the cursor.
            for (int i = 0; i < _tracers.Length; i++)
            {
                int index = (_tracerCursor + i) % _tracers.Length;
                var tracer = GetUsableTracer(index);
                if (!tracer.IsFree)
                {
                    continue;
                }
                _tracerCursor = (index + 1) % _tracers.Length;
                tracer.TryPlay(from, to);
                return tracer;
            }

            var recycled=GetUsableTracer(_tracerCursor);
            recycled.TryPlay(from, to);
            _tracerCursor = (_tracerCursor + 1) % _tracers.Length;
            return recycled;
        }

        private void Update()
        {
            bool dead = health != null && health.IsDead;

            // No flinch when a round lands: Nam (and Hùng in the tutorial) keeps his aim. The controller's
            // "Hit" state (Nam_HitReaction) is no longer triggered.

            // The magazine is ticked before any early return. Dying halfway through a reload
            // would otherwise leave the timer frozen for good, and a magazine that believes it
            // is reloading refuses to fire — the weapon would come back from the respawn dead.
            if (dead)
            {
                _magazine?.CancelReload();
                _spread.Reset();
                if (cameraRig != null) cameraRig.ClearRecoil();
            }
            else
            {
                _magazine?.Tick(Time.deltaTime, DrawRounds);
                _spread.Tick(Time.deltaTime, _equipped != null && _equipped.UsesM16Handling);
            }

            if (dead || _handsOccupied || (InputAllowed != null && !InputAllowed()))
            {
                _firingHeld = false;
                _automaticBurst = false;
                SetAiming(false);
                if(animator != null) animator.SetBool(AnimatorParams.Aiming, false);
                _faceCameraHoldUntil = 0f;
                _fireHoldUntil = 0f;
                if (_controller != null)
                {
                    _controller.SetFaceCameraYaw(false);
                }
                return;
            }

            ReadEquipInput();
            ReadAimInput();
            ReadReloadInput();
            ReadAttackInput();
            // Holding the trigger keeps the shooting stance up between rounds without enabling camera ADS.
            if(animator != null) animator.SetBool(AnimatorParams.Aiming, _aiming || _firingHeld);
            UpdateFacing();
            UpdateUpperBodyWeight();
            UpdateGripPose();
        }

        /// <summary>
        /// Swings the weapon between the carry pose it rides in while moving and the levelled pose
        /// it takes to shoot. The arms come from the animation; only the weapon's seat in the hand
        /// changes, which is what separates "slung over the shoulder" from "aimed".
        /// </summary>
        private void UpdateGripPose()
        {
            if (_equipped == null || gripConfig == null
                || !gripConfig.TryGetOffset(_equippedKind, out WeaponGripConfig.GripOffset offset)
                || !offset.hasAimPose)
            {
                return;
            }

            bool levelled = _aiming || _firingHeld || Time.time < _upperBodyHoldUntil;
            _aimPoseBlend = Mathf.MoveTowards(
                _aimPoseBlend, levelled ? 1f : 0f, Time.deltaTime / Mathf.Max(0.01f, gripBlendTime));

            WeaponGripConfig.GetPose(offset, false, out Vector3 carryPos, out Quaternion carryRot);
            WeaponGripConfig.GetPose(offset, true, out Vector3 aimPos, out Quaternion aimRot);
            _equipped.transform.SetLocalPositionAndRotation(
                Vector3.Lerp(carryPos, aimPos, _aimPoseBlend),
                Quaternion.Slerp(carryRot, aimRot, _aimPoseBlend));
        }

        /// <summary>
        /// Who the body faces. Walking, it follows the legs. Aiming or shooting, it locks to the
        /// camera's yaw so the barrel points where the player is looking — that turn is what puts
        /// the character into the bladed stance the Gunplay take was authored around.
        /// Pushed every frame rather than from the aim toggle alone, because firing turns the body
        /// too and that turn has to time out on its own.
        /// </summary>
        private void UpdateFacing()
        {
            if (_controller == null)
            {
                return;
            }

            bool locked = _aiming || _firingHeld || Time.time < _faceCameraHoldUntil;
            bool holdingGun = _equipped != null && _equipped.IsGun;
            _controller.SetFaceCameraYaw(locked, locked && holdingGun ? -PoseAimYaw() : 0f);
        }

        /// <summary>
        /// How far round from the character's own forward the pose is pointing the rifle. Read
        /// straight off the barrel, because that is the thing that has to end up on the crosshair.
        /// The Mixamo shooting take aims about 87 degrees to the character's left, which is why
        /// firing has to stand the body side-on to the target.
        /// <para>
        /// Measured live rather than stored as a constant: re-seat the weapon in the hand or swap
        /// the shooting clip for one that aims straight ahead, and this follows on its own instead
        /// of leaving a stale number turning the body for no reason.
        /// </para>
        /// </summary>
        private float PoseAimYaw()
        {
            if (_controller != null && _controller.IsProne) return 0f;
            // Recoil moves the arms, not the feet. Keep the last resting aim reference through each kick.
            if (RecoilPosePlaying) return _stanceYaw;
            Transform muzzle = _equipped != null ? _equipped.Muzzle : null;
            if (muzzle == null)
            {
                return 0f;
            }

            // The barrel as the take holds it. BarrelAim bends the spine afterwards to put it on the
            // crosshair, and reading that back would count the correction as the pose's own: the body
            // would stop turning and leave the spine to twist the whole way.
            if (_barrelAim != null && _barrelAim.TryGetPoseYaw(out float posed))
            {
                return _stanceYaw = posed;
            }

            Vector3 barrel = Vector3.ProjectOnPlane(muzzle.forward, Vector3.up);
            // Barrel straight up or down carries no yaw; leave the body facing the camera.
            return _stanceYaw = barrel.sqrMagnitude < 0.0004f
                ? 0f
                : Vector3.SignedAngle(transform.forward, barrel.normalized, Vector3.up);
        }

        /// <summary>
        /// The stance layer is faded out when empty-handed. An override layer whose state has no
        /// motion writes nothing, so it would otherwise hold the last armed pose forever — which
        /// is exactly what made putting the knife away leave the character still gripping it.
        /// The layer is forced back up while an attack plays, so the punch still reaches the arms.
        /// </summary>
        private void UpdateUpperBodyWeight()
        {
            if (animator == null || _upperBodyLayer <= 0)
            {
                return;
            }

            bool attacking = Time.time < _upperBodyHoldUntil;
            // With Nam's own AK carry in the base layer (Locomotion_Rifle), his arms already hold the
            // rifle: the stance layer only comes up to aim, fire, reload or take a hit.
            bool carried = _rifleBody && _equippedKind == WeaponKind.Rifle && !_aiming && !_firingHeld && !attacking
                && (_magazine == null || !_magazine.IsReloading);
            // The cheap tests first: this runs every frame, the animator is only asked with the knife out.
            if(_equippedKind==WeaponKind.Knife&&!attacking&&HasKnifeCarry) {
                var state=animator.GetCurrentAnimatorStateInfo(0);
                carried|=state.IsName("Locomotion_Knife")||state.IsName("Sneak_Knife");
            }
            float target = (_equippedKind != WeaponKind.Unarmed || attacking) && !carried ? 1f : 0f;
            _upperBodyWeight = Mathf.MoveTowards(
                _upperBodyWeight, target, Time.deltaTime / Mathf.Max(0.01f, stanceBlendTime));
            animator.SetLayerWeight(_upperBodyLayer, _upperBodyWeight);
        }

        // ---- Input ----------------------------------------------------------

        private void ReadEquipInput()
        {
            Keyboard kb = Keyboard.current;
            if (kb == null)
            {
                return;
            }

            for (int slot = 0; slot < SlotKeys.Length; slot++)
            {
                if (!kb[SlotKeys[slot]].wasPressedThisFrame) continue;
                if (SlotPressed != null && SlotPressed(slot)) return;
                // A key past the end of SlotOrder has nothing to draw.
                if (slot < SlotOrder.Length) Equip(SlotOrder[slot]);
                return;
            }
        }

        private void ReadAimInput()
        {
            if (_equipped == null || !_equipped.IsGun)
            {
                SetAiming(false);
                return;
            }

            // Aim follows the held button; release returns to normal movement/facing.
            SetAiming(Mouse.current != null && Mouse.current.rightButton.isPressed);
        }

        /// <summary>
        /// Reads how steady the shooter is right now. Feet off the ground beats everything —
        /// a sneaking player who jumps is not sneaking any more.
        /// </summary>
        private ShooterStance CurrentStance()
        {
            if (_controller == null) return ShooterStance.Standing;
            return WeaponSpreadState.ResolveStance(_characterController == null || _characterController.isGrounded,
                _controller.IsSneaking, _controller.IsSprinting, _controller.PlanarSpeed);
        }

        private void ReadReloadInput()
        {
            Keyboard keyboard = Keyboard.current;
            if (keyboard != null && keyboard.rKey.wasPressedThisFrame) TryReload();
        }

        private void ReadAttackInput()
        {
            Mouse mouse = Mouse.current;
            _firingHeld = mouse != null && mouse.leftButton.isPressed && Gun != null && !IsReloading
                && (_magazine == null || _magazine.Rounds > 0);
            if (mouse == null)
            {
                _automaticBurst = false;
                return;
            }

            bool automatic = _equipped != null && _equipped.Automatic;
            bool pressed = automatic ? mouse.leftButton.isPressed : mouse.leftButton.wasPressedThisFrame;
            bool continuing = _automaticBurst;
            _automaticBurst = automatic && pressed && !IsReloading;
            if (!pressed || Time.time < _nextAttackTime)
            {
                return;
            }

            if (!automatic || !continuing) { Attack(); return; }

            // A slow frame may contain several scheduled rounds. Preserve their deadlines rather than
            // silently reducing the fire rate to the frame rate. Never replay a long backlog after a stall.
            const int maxCatchUp = 4;
            int fired = 0;
            while (Time.time >= _nextAttackTime && fired < maxCatchUp)
            {
                float deadline = _nextAttackTime;
                float cooldown = _equipped.Cooldown;
                Attack();
                if (_nextAttackTime <= deadline) break; // Empty, reloading, broken or otherwise refused.
                _nextAttackTime = deadline + cooldown;
                fired++;
                if (_equipped == null || !_equipped.Automatic || IsReloading) break;
            }
            if (fired == maxCatchUp && _nextAttackTime <= Time.time)
                _nextAttackTime = Time.time + _equipped.Cooldown;
        }

        // ---- Actions --------------------------------------------------------

        /// <summary>
        /// Puts <paramref name="kind"/> in hand. There are no bare hands to fall back to: asking for a
        /// weapon there is no prefab for keeps the one in hand and returns false.
        /// </summary>
        public bool Equip(WeaponKind kind)
        {
            if(EquipAllowed!=null&&!EquipAllowed(kind))return false;
            _weapons.TryGetValue(kind, out Weapon next);
            if (next == null)
            {
                // Only a scene with no weapons at all ends up empty-handed (the Unarmed default).
                if (kind != WeaponKind.Unarmed) Debug.LogWarning($"[Combat] No prefab for {kind}: keeping {_equippedKind} in hand.", this);
                return false;
            }
            if (next == _equipped) return true;

            CancelReload();

            if (_equipped != null)
            {
                _equipped.gameObject.SetActive(false);
            }

            _equipped = next;
            _equippedKind = next.Kind;
            GunPresentationReady=true;
            if (_magazines.TryGetValue(_equippedKind, out var magazine))
            {
                _magazine = magazine; _activeTuning = _tunings[_equippedKind];
            }
            _equipped.gameObject.SetActive(true);

            if (animator != null)
            {
                animator.SetInteger(AnimatorParams.Weapon, (int)_equippedKind);
            }

            // Sights belong to the gun that was holstered.
            if (!_equipped.IsGun)
            {
                SetAiming(false);
            }

            WeaponChanged?.Invoke(_equippedKind);
            return true;
        }

        private void SetAiming(bool value)
        {
            if (_aiming == value)
            {
                return;
            }

            _aiming = value;
            if (animator != null)
            {
                animator.SetBool(AnimatorParams.Aiming, value);
            }
            if (cameraRig != null)
            {
                cameraRig.SetAiming(value);
            }
        }

        private void Attack()
        {
            // Nothing in hand (a scene without weapon prefabs): there is no punch any more.
            if (_equipped == null) return;
            if (_equippedKind == WeaponKind.Knife && TrySpecialMelee != null && TrySpecialMelee()) return;
            // Everything that can refuse the shot is settled before a single side effect runs.
            // Pulling the trigger on an empty magazine used to burn the cooldown and play the
            // firing animation anyway, so the weapon mimed a shot it never took.
            bool firingGun = _equipped != null && _equipped.IsGun;
            if (firingGun)
            {
                if (GunUsable != null && !GunUsable()) return;
                if (_magazine != null)
                {
                    if (!_magazine.TryConsume())
                    {
                        // Out, or mid-reload. Reaching for a fresh magazine is what the player
                        // meant by pulling the trigger on an empty gun.
                        TryReload();
                        return;
                    }
                }
                else if (TryConsumeRound != null && !TryConsumeRound())
                {
                    return;
                }
            }

            float cooldown = _equipped != null ? _equipped.Cooldown : punchCooldown;

            // `Time.time + cooldown` rounds every gap up to a whole frame, quietly turning 600
            // rounds per minute into 500 at 50 fps. Carrying the remainder forward fixes that
            // during sustained fire, but only while the weapon is genuinely mid-burst: once the
            // schedule is more than a cooldown stale the burst is over, and resuming from it
            // would leave no delay at all before the next shot.
            _nextAttackTime = Time.time - _nextAttackTime > cooldown
                ? Time.time + cooldown
                : _nextAttackTime + cooldown;

            // The muzzle is where a gunshot is heard from; an empty hand has none, so fall back
            // to the character. Raised before the trace so a listener cannot miss a kill's shot.
            Transform sound = _equipped != null && _equipped.Muzzle != null ? _equipped.Muzzle : transform;
            // Mosin's attack event starts its bolt cycle and closes the PU scope.
            // Freeze the ray the player actually aimed before that camera transition;
            // effects still resolve after this frame's animated muzzle is positioned.
            Ray? scopedRay = null;
            if(_equippedKind==WeaponKind.Sniper && cameraRig!=null && cameraRig.IsWeaponScope) {
                var scopeCamera=Camera.main;
                if(scopeCamera!=null)scopedRay=new Ray(scopeCamera.transform.position,scopeCamera.transform.forward);
            }
            Attacked?.Invoke(_equippedKind, sound.position);

            _upperBodyHoldUntil = Time.time + cooldown + attackLayerTail;
            if (animator != null && _equippedKind != WeaponKind.Pistol && _equippedKind != WeaponKind.Sniper)
            {
                animator.SetTrigger(AnimatorParams.Attack);
            }

            if (_equipped != null && _equipped.IsGun)
            {
                _faceCameraHoldUntil = Time.time + cooldown + faceCameraTail;
                _fireHoldUntil = _upperBodyHoldUntil;
                _pendingGunfire.Add(new PendingGunShot(_equipped,CurrentStance(),_aiming,scopedRay));
            }
            else
            {
                SwingMelee();
            }
        }

        private readonly struct PendingGunShot
        {
            public readonly Weapon Gun;public readonly ShooterStance Stance;public readonly bool Aiming;public readonly Ray? ScopedRay;
            public PendingGunShot(Weapon gun,ShooterStance stance,bool aiming,Ray? scopedRay){Gun=gun;Stance=stance;Aiming=aiming;ScopedRay=scopedRay;}
        }
        private readonly System.Collections.Generic.List<PendingGunShot> _pendingGunfire=new();

        internal void ResolvePendingGunfire()
        {
            if(!isActiveAndEnabled){_pendingGunfire.Clear();return;}
            while(isActiveAndEnabled && _pendingGunfire.Count>0) {
                var shot=_pendingGunfire[0];_pendingGunfire.RemoveAt(0);
                if(shot.Gun!=null)FireShotAlongRay(shot.Gun,shot.Stance,shot.Aiming,shot.ScopedRay);
            }
            _pendingGunfire.Clear();
        }

        private void OnDisable() => _pendingGunfire.Clear();

        /// <summary>Resolve after animation and barrel aim, using this frame's camera and muzzle.</summary>
        private void FireGun(Weapon gun)
            => FireShot(gun,CurrentStance(),_aiming);

        private void FireShot(Weapon gun,ShooterStance stance,bool aiming)
            => FireShotAlongRay(gun,stance,aiming,null);

        private void FireShotAlongRay(Weapon gun,ShooterStance stance,bool aiming,Ray? scopedRay)
        {
            Camera cam = Camera.main;
            if (cam == null)
            {
                return;
            }

            Vector3 origin = scopedRay?.origin ?? cam.transform.position;
            Vector3 direction = scopedRay?.direction ?? cam.transform.forward;

            // How steady the shooter is decides the cone, and how long they have held the
            // trigger widens it. The weapon's own HipSpread is no longer consulted: one flat
            // number could not tell a crouched aimed tap from a shot fired mid-jump.
            Vector2 kick = _spread.Fire(Time.time, gun.UsesM16Handling);
            direction = WeaponSpreadState.Scatter(direction, _spread.ConeHalfAngle(stance, aiming, gun.Kind, gun.UsesM16Handling));
            if (gun.Kind == WeaponKind.Sniper) kick = new Vector2(1.8f,.12f);
            var skills = GetComponent<ShadowVale.Gameplay.Skills.PlayerSkills>();
            if (skills != null) kick *= skills.RecoilMultiplier;
            if (cameraRig != null) cameraRig.AddRecoil(kick.x, kick.y);

            // The trace starts at the camera so the shot lands on the crosshair, but the streak
            // has to come out of the barrel or it looks like the player is firing from their eyes.
            Vector3 endPoint;
            if (TryShotHit(origin, direction, gun.Range, out RaycastHit hit))
            {
                var health = hit.collider.GetComponentInParent<Health>();
                bool alive = health != null && !health.IsDead;
                if (health != null) health.TakeBulletDamageFromWeapon(gun.DamageAgainst(health), hit.point, gameObject, direction, gun.Kind, gun.IsLethalAgainst(health));
                else ApplyDamage(hit.collider, gun.Damage, hit.point);
                if (alive && health.IsDead) GunKilled?.Invoke(health.gameObject);
                endPoint = hit.point;
            }
            else
            {
                endPoint = origin + direction * gun.Range;
            }

            PlayTracer(gun.Muzzle.position, endPoint)?.AnchorEmission(gun.Muzzle);
            gun.PlayMuzzleFlash();
        }

        /// <summary>
        /// Colliders a round goes straight through, set by a map (Map 1: its thatch and zinc roofs, which stop no
        /// rifle bullet). Null: the first collider on the line stops it, as before.
        /// </summary>
        public System.Func<Collider, bool> ShotPassesThrough { get; set; }

        /// <summary>The first thing on the line that stops the round.</summary>
        private bool TryShotHit(Vector3 origin, Vector3 direction, float range, out RaycastHit hit)
        {
            if (ShotPassesThrough == null)
                return Physics.Raycast(origin, direction, out hit, range, hitMask, QueryTriggerInteraction.Ignore);
            hit = default;
            bool found = false;
            foreach (var h in Physics.RaycastAll(origin, direction, range, hitMask, QueryTriggerInteraction.Ignore))
                if ((!found || h.distance < hit.distance) && !ShotPassesThrough(h.collider)) { hit = h; found = true; }
            return found;
        }

        /// <summary>Sphere sweep forward from chest height — forgiving enough for a greybox test.</summary>
        private void SwingMelee()
        {
            float range = _equipped != null ? _equipped.Range : punchRange;
            float radius = _equipped != null ? _equipped.SweepRadius : punchSweepRadius;
            float damage = _equipped != null ? _equipped.Damage : punchDamage;

            Vector3 origin = transform.position + Vector3.up * 1.2f;
            if (Physics.SphereCast(origin, radius, transform.forward, out RaycastHit hit, range,
                    hitMask, QueryTriggerInteraction.Ignore))
            {
                ApplyDamage(hit.collider, damage, hit.point);
            }
        }

        /// <summary>A lethal gun hit, never melee, corpse hits, restores or scripted damage.</summary>
        public event System.Action<GameObject> GunKilled;

        private void ApplyDamage(Collider target, float amount, Vector3 point)
        {
            var damageable = target.GetComponentInParent<IDamageable>();
            damageable?.TakeDamage(amount, point, gameObject);
        }
    }
}
